#ifndef GLOBAL_VARIABLES_H
#define GLOBAL_VARIABLES_H
#include<windows.h>
#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include<math.h>>
# define PI          3.14159265358979323846


extern GLfloat i;
extern GLfloat xr;
extern GLfloat yr;
extern GLfloat position;
extern GLfloat speed;

extern GLfloat position1;
extern GLfloat speed1;

extern GLfloat position2;
extern GLfloat speed2;
extern GLfloat position3;
extern GLfloat speed3;

extern GLfloat pb;
extern GLfloat sb;


#endif

