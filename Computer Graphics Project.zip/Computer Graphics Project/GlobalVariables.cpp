#include<windows.h>
#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846
#include "GlobalVariables.h"

GLfloat i = 0.0f;

GLfloat xr = 0.0f;
GLfloat yr = 0.0f;
GLfloat position = 0.0f;
GLfloat speed = 0.01f;

GLfloat position1 = 0.0f;
GLfloat speed1 = 0.1f;

GLfloat position2 = 0.0f;
GLfloat speed2 = 0.001f;
GLfloat position3 = 0.0f;
GLfloat speed3 = 0.004f;

GLfloat pb = 0.0f;
GLfloat sb = 0.001f;

