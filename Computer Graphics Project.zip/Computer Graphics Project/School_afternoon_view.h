#ifndef SCHOOL_AFTERNOON_VIEW_H
#define SCHOOL_AFTERNOON_VIEW_H
#include<windows.h>
#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846

void School_afternoon_view();

#endif
