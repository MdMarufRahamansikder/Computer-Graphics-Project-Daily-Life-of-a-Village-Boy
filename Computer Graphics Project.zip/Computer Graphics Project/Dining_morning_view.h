#ifndef DINING_MORNING_VIEW_H
#define DINING_MORNING_VIEW_H
#include<windows.h>
#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846

void Dining_morning_view();

#endif
