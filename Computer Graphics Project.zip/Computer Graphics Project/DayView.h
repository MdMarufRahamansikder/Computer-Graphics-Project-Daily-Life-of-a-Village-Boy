#ifndef DAYVIEW_H
#define DAYVIEW_H
#include<windows.h>
#include<cstdio>
#include <GL/gl.h>
#include <GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846

void DayView();

#endif

